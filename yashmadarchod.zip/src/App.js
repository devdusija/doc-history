import { useEffect, useState } from "react";
import { AuthProvider, useAuth } from "./auth/AuthContext";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import ChatInterface from "./pages/ChatInterface";
import UploadDocument from "./pages/UploadDocument";

const ProtectedRoute = ({ element: Element, ...rest }) => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return <Navigate to="/" />;
  }

  return <Element {...rest} />;
};

const AuthenticatedApp = () => {
  const { currentUser } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(false);
  }, [currentUser]);

  if (isLoading) {
    return null; // or a loading indicator
  }

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={currentUser ? <Navigate to="/dashboard" /> : <Login />}
        />
        {/* <Route
          path="/login"
          element={<Login />}
        /> */}
        <Route path="/dashboard" element={<ProtectedRoute element={Dashboard} />} />
        <Route path="/upload-document" element={<ProtectedRoute element={UploadDocument} />} />

        {/* <Route path="/chat" element={<ProtectedRoute element={ChatInterface } />} /> */}

      </Routes>
    </Router>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <AuthenticatedApp />
    </AuthProvider>
  );
};

export default App;
